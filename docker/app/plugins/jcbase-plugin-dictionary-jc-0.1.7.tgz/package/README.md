# @jcbase/plugin-dictionary-jc

NocoBase 字典管理插件，提供字典类型与字典值管理能力。
