# @jcbase/plugin-config-center-jc

面向运维人员的 NocoBase 配置中心插件，用于统一管理系统参数，降低多插件、多页面分散配置带来的维护成本和误操作风险。

## 功能概览

- 按“模块 -> 分组 -> 参数”分层维护配置。
- 支持 `string`、`text`、`number`、`boolean`、`select`、`json` 六类参数值。
- 支持参数说明、必填、启用、排序、扩展 `schema` 校验信息。
- 提供统一设置页，支持结构维护、参数值维护、JSON 编辑、已存值预览。
- 支持配置导出和导入，适合环境迁移或备份。
- 插件首次启用时会自动初始化一套默认模板。
- 提供读取型 API，供其他插件或前端按 `key` 获取配置值。
- 提供匿名只读 API，供登录页等未登录场景实时读取公开配置。

## 默认模板

插件在首次启用且三张内部表均为空时，会自动写入一套内置模板：

- 模块：`portal`
- 分组：`login`、`session`、`appearance`、`modules`
- 示例参数：
  - `allow_sso`
  - `password_login_enabled`
  - `direct_jc4a_login_enabled`
  - `login_captcha_enabled`
  - `session_timeout_minutes`
  - `concurrent_session_limit`
  - `site_title`
  - `site_logo`
  - `theme_mode`
  - `footer_links`

在设置页中还提供“初始化默认模板”按钮。该操作会覆盖当前模块、分组和参数结构，适合重建基线配置时使用。

## 数据结构

插件内部维护三张表：

- `jcConfigCenterModules`
- `jcConfigCenterGroups`
- `jcConfigCenterItems`

设计原则：

- 表结构保持轻量，适合运维录入。
- 复杂配置尽量通过 `schema` 和 `value` 的 JSON 扩展字段表达。
- 下拉选项、数字范围、占位提示等统一放在 `schema` 中。

## 页面使用

设置页入口：

- 后台插件设置 -> `配置中心`

页面分为四块：

- 模块列表：维护模块编码、名称、说明、启用状态、排序。
- 分组列表：维护当前模块下的分组。
- 参数列表：维护当前分组下的参数定义与扩展定义。
- 配置预览区：按模块 `Tabs`、按分组 `Card` 展示最终可编辑参数值。

建议运维使用流程：

1. 先维护模块、分组、参数结构。
2. 点击“保存结构”。
3. 再在下方预览区维护各参数值。
4. 点击“统一保存参数值”。

## 参数类型说明

### `string`

- 单行文本。
- 常用于标题、编码、路径、域名等简单字符串。

### `text`

- 多行文本。
- 常用于说明、模板片段、富文本前的纯文本配置。

### `number`

- 数字输入。
- 可在 `schema` 中定义 `min`、`max`、`step`。

### `boolean`

- 开关输入。
- 常用于启用/禁用类参数。

### `select`

- 下拉选择。
- 必须在 `schema.options` 中配置选项，例如：

```json
{
  "options": [
    { "label": "浅色", "value": "light" },
    { "label": "深色", "value": "dark" }
  ]
}
```

### `json`

- 复杂结构配置。
- 适合对象、数组、嵌套规则等难以拆字段的场景。

## 导入导出格式

导出内容为 JSON，结构如下：

```json
{
  "modules": [
    {
      "key": "portal",
      "title": "门户配置",
      "description": "门户站点级基础参数",
      "sort": 0,
      "enabled": true,
      "groups": [
        {
          "moduleKey": "portal",
          "key": "appearance",
          "title": "界面配置",
          "description": "站点展示参数",
          "sort": 2,
          "enabled": true,
          "items": [
            {
              "moduleKey": "portal",
              "groupKey": "appearance",
              "key": "theme_mode",
              "title": "主题模式",
              "valueType": "select",
              "required": true,
              "enabled": true,
              "sort": 1,
              "value": "light",
              "schema": {
                "options": [
                  { "label": "浅色", "value": "light" },
                  { "label": "深色", "value": "dark" }
                ]
              }
            }
          ]
        }
      ]
    }
  ]
}
```

当前服务端同时兼容两种导入格式：

- 树形结构：`{ modules: [{ groups: [{ items: [] }] }] }`
- 扁平结构：`{ modules: [], groups: [], items: [] }`

这意味着导出的 JSON 可以直接原样再导入。

## API 说明

资源名：

- `jcConfigCenter`

支持动作：

- `listTree`
- `saveStructure`
- `saveValues`
- `exportBundle`
- `importBundle`
- `initializePreset`
- `getValue`
- `getValues`
- `publicGetValue`
- `publicGetValues`

### 读取单个参数

请求参数：

```json
{
  "key": "theme_mode",
  "moduleKey": "portal",
  "groupKey": "appearance"
}
```

返回示例：

```json
{
  "key": "theme_mode",
  "moduleKey": "portal",
  "groupKey": "appearance",
  "valueType": "select",
  "value": "light",
  "schema": {
    "options": [
      { "label": "浅色", "value": "light" }
    ]
  },
  "required": true,
  "enabled": true
}
```

### 批量读取参数

请求参数：

```json
{
  "moduleKey": "portal",
  "keys": ["site_title", "theme_mode"]
}
```

## 供其他插件调用

### HTTP 调用

前端或远程服务可直接调用资源动作：

- `jcConfigCenter:getValue`
- `jcConfigCenter:getValues`
- `jcConfigCenter:publicGetValue`
- `jcConfigCenter:publicGetValues`

### 匿名公开读取

匿名接口只开放登录页等未登录场景所需的白名单配置项，当前包含：

- `site_title`
- `allow_sso`
- `password_login_enabled`
- `direct_jc4a_login_enabled`
- `login_captcha_enabled`

说明：

- `publicGetValue`：读取单个白名单配置项，非白名单 key 返回 `null`。
- `publicGetValues`：批量读取白名单配置项，非白名单 key 会被自动过滤。
- 现有 `getValue` / `getValues` 仍保持登录后可读，不会因为新增匿名接口而放开整个配置中心。

### 服务端进程内调用

插件已将服务注册到应用容器：

- 服务标识：`jcbase.config-center`

示例：

```ts
const service = app.container.get<any>('jcbase.config-center');
const result = await service.getValue({
  key: 'site_title',
  moduleKey: 'portal',
  groupKey: 'appearance',
});
```

这适合其他服务端插件在同进程内读取配置，避免额外走 HTTP。

## 权限

ACL snippet：

- `pm.config-center-jc`

已开放给登录用户的资源动作：

- `jcConfigCenter:*`
- `jcConfigCenterModules:*`
- `jcConfigCenterGroups:*`
- `jcConfigCenterItems:*`

如需细分权限，可在宿主系统中进一步按角色控制。

## 开发验证

在宿主工程根目录并使用 Node 20：

```bash
PATH=/Users/fish/.nvm/versions/node/v20.20.2/bin:$PATH yarn test packages/plugins/@jcbase/plugin-config-center-jc/src/server/__tests__/config-center-api.test.ts
PATH=/Users/fish/.nvm/versions/node/v20.20.2/bin:$PATH yarn test packages/plugins/@jcbase/plugin-config-center-jc/src/client/__tests__/plugin.test.tsx
PATH=/Users/fish/.nvm/versions/node/v20.20.2/bin:$PATH yarn build @jcbase/plugin-config-center-jc
```
